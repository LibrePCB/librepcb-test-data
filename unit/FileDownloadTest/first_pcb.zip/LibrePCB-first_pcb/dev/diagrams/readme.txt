All diagrams are created with "Dia": http://live.gnome.org/Dia

Please save all projects uncompressed (file -> save as -> uncheck "compress file")!
