# LibrePCB Application

This directory contains the qmake project of the LibrePCB application.

The dependencies between application and static libraries are shown in the [architecture overview diagram](../dev/diagrams/svg/architecture_overview.svg):

![Architecture Overview Diagram](../dev/doxygen/images/architecture_overview.png)
