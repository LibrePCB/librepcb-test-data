# Static Libraries

This directory contains all static libraries (as qmake projects) required to build the LibrePCB application and other tools. 

The dependencies between these libraries are shown in the [architecture overview diagram](../dev/diagrams/svg/architecture_overview.svg):

![Architecture Overview Diagram](../dev/doxygen/images/architecture_overview.png)
