# 3rd-party Stuff

This directory contains 3rd-party stuff (libraries, applications, ...).
