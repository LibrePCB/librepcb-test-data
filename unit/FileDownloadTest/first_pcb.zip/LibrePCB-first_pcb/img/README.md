# Images

This directory contains all images which are required in the LibrePCB application or other tools.

- Most images are from the "Open Icon Library": http://openiconlibrary.sourceforge.net/
- Some images are from https://www.iconfinder.com/
