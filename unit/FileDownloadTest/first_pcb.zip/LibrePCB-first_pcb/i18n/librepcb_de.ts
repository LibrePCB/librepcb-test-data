<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>ControlPanel</name>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="14"/>
        <source>LibrePCB ControlPanel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="100"/>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="447"/>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="289"/>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="418"/>
        <source>New Project</source>
        <translation>Neues Projekt</translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="117"/>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="456"/>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="308"/>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="392"/>
        <source>Open Project</source>
        <translation>Projekt öffnen</translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="134"/>
        <source>Library Editor</source>
        <translation>Bibliotheks-Editor</translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="186"/>
        <source>Recent Projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="259"/>
        <source>Favorite Projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="333"/>
        <source>Project description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="349"/>
        <source>about:blank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="375"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="387"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="394"/>
        <source>Extras</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="412"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="415"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="423"/>
        <source>About Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="435"/>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="279"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="461"/>
        <source>Switch Workspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="470"/>
        <source>Workspace Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="482"/>
        <source>Open Library Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="491"/>
        <source>Close all open projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.ui" line="496"/>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="535"/>
        <source>Rescan Library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="49"/>
        <source>Control Panel - LibrePCB %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="51"/>
        <source>Workspace: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="195"/>
        <source>Could not create project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="219"/>
        <source>Could not open project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="279"/>
        <source>LibrePCB is a free &amp; OpenSource Schematic/Layout-Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="290"/>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="309"/>
        <source>LibrePCB project files (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="331"/>
        <source>Workspace changed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="332"/>
        <source>The chosen workspace will be used after restarting the application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="398"/>
        <source>Close Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="404"/>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="497"/>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="522"/>
        <source>Remove from favorites</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="410"/>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="502"/>
        <source>Add to favorites</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="421"/>
        <source>New Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="424"/>
        <source>Open Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/controlpanel/controlpanel.cpp" line="541"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FirstRunWizard</name>
    <message>
        <location filename="../librepcb/firstrunwizard/firstrunwizard.ui" line="17"/>
        <source>Choose LibrePCB Workspace</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FirstRunWizardPage_Welcome</name>
    <message>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_welcome.ui" line="14"/>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_welcome.ui" line="17"/>
        <source>Welcome to LibrePCB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_welcome.ui" line="20"/>
        <source>This wizard will help you to open or create a LibrePCB workspace.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_welcome.ui" line="26"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt; font-weight:600;&quot;&gt;Welcome To LibrePCB&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_welcome.ui" line="43"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Website: &lt;a href=&quot;http://librepcb.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://librepcb.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;GitHub Project: &lt;a href=&quot;https://github.com/LibrePCB&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;https://github.com/LibrePCB&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;LibrePCB is published under the &lt;a href=&quot;http://www.gnu.org/licenses/gpl-3.0.html&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;GNU GPLv3&lt;/span&gt;&lt;/a&gt; License.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FirstRunWizardPage_WorkspacePath</name>
    <message>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_workspacepath.ui" line="14"/>
        <source>WizardPage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_workspacepath.ui" line="17"/>
        <source>Select Workspace Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_workspacepath.ui" line="20"/>
        <source>Please select a directory to open or create a LibrePCB workspace.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_workspacepath.ui" line="32"/>
        <source>LibrePCB needs a workspace directory to store settings, libraries and projects.

Workspaces are platform independent, so they can be used across different operating systems.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_workspacepath.ui" line="51"/>
        <source>Create a new workspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_workspacepath.ui" line="61"/>
        <source>Choose an empty directory to create a new workspace:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_workspacepath.ui" line="76"/>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_workspacepath.ui" line="124"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_workspacepath.ui" line="92"/>
        <source>Open an existing workspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_workspacepath.ui" line="102"/>
        <source>Select the workspace directory:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_workspacepath.cpp" line="65"/>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_workspacepath.cpp" line="77"/>
        <source>Invalid Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_workspacepath.cpp" line="66"/>
        <source>The selected directory is invalid or not empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_workspacepath.cpp" line="78"/>
        <source>The selected directory is not a valid workspace.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_workspacepath.cpp" line="111"/>
        <source>Select Empty Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/firstrunwizard/firstrunwizardpage_workspacepath.cpp" line="118"/>
        <source>Select Workspace Directory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LibraryEditor</name>
    <message>
        <source>Library Editor</source>
        <translation type="obsolete">Bibliotheks-Editor</translation>
    </message>
</context>
<context>
    <name>Workspace</name>
    <message>
        <location filename="../librepcb/main.cpp" line="130"/>
        <source>Could not create the workspace directory. Check file permissions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/main.cpp" line="152"/>
        <source>Cannot open the workspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/main.cpp" line="153"/>
        <source>The workspace &quot;%1&quot; cannot be opened: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../librepcb/main.cpp" line="129"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WorkspaceSettingsDialog</name>
    <message>
        <source>Library Editor</source>
        <translation type="obsolete">Bibliotheks-Editor</translation>
    </message>
</context>
</TS>
